package com.project.repository.product;

public interface ICategoryRepository {
}
