export interface GrantList {
  id?: number;
  roleName?: string;
  isDeleted?: number;
}
