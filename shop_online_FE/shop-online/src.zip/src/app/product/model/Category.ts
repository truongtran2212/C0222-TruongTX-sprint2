export interface Category {
  id?: number;
  name?: string;
  discountPercent?: number;
  image?: string;
  isDeleted?: number;
}
